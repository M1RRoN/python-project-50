#!/usr/bin/env python3
from gendiff.gendiff import gendiff


def main():
    gendiff()


if __name__ == '__main__':
    main()
